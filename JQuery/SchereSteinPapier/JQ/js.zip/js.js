function speichern() {
    var Score = 0;
    let inh = inhalt.value;
    // Wert wird im localStorage gespeichert
    localStorage.setItem(bez, inh);
    }
        function ausgeben() {
        let ausgabe = "";
        let i = 0;
        for (let wert in localStorage) {
        // mit getItem() wird der Wert aus // dem localStorage abgerufen
        ausgabe += wert + ": " + localStorage.getItem(wert);
        ausgabe += "<br>";
        i++;
        // Um weitere Attribute und Methoden des Objektes nicht
        // auszugeben = zusätzlicher Zähler der die Länge des// Eintrages überprüft
            if(i == localStorage.length) {
            break;
            }
        }
        pAusgabe.innerHTML = ausgabe;
    }

"use strict"
let feld = 1;
function delStorage() {
// Werte werden gelöscht
localStorage.clear()
}


function getRandom(max){
    return Math.floor(Math.random() * max);
}

let x = 0;
let y = 0;
let z = 0;

switch(score) {

    case 1:
        x = getRandomInt(50);
        y = getRandomInt(50);

        if((prompt(x + "+" + y + "=")) == (x + y)){
            return true;
        }
        else{
            return false;
        }
        break;

    case 2:
        x = getRandomInt(50) + 50;
        y = getRandomInt(50);

        if((prompt(x + "-" + y + "=")) == (x - y)){
            return true;
        }
        else{
            return false;
        }
        break;
    
    case 3:
        x = getRandomInt(10);
        y = getRandomInt(10);

        if((prompt(x + "*" + y + "=")) == (x * y)){
            return true;
        }
        else{
            return false;
        }
        break;

    case 4:
        x = getRandomInt(17) + 3;
        y = getRandomInt(9) + 1;       // y == ergebnis;

        z = x * y;              // z == dividend;



        if((prompt(z + "/" + x + "=")) == (y)){
            return true;
        }
        else{
            return false;
        }
        break;

    case 5:
    case 6:
    case 7:
        x = getRandomInt(50);
        y = getRandomInt(50);
        z = getRandomInt(50);

        if((prompt(x + "+" + y + "+" + z + "=")) == (x + y + z)){
            return true;
        }
        else{
            return false;
        }
        break;

    case 8:
        x = getRandomInt(12) + 3;        // ergebnis

        y = Math.pow(x, 2);


        if((prompt("√" + y + "=")) == (x)){
            return true;
        }
        else{
            return false;
        }
        break;

    case 9:
        x = getRandomInt(4) + 1;        // basis
        y = getRandomInt(3) + 1;        // ergebnis

        z = Math.pow(x, y);     // numerus


        if((prompt(x + "^x" + "=" + z + "  Get x.")) == (y)){
            return true;
        }
        else{
            return false;
        }
        break;


}

function reset(){

    // ist auch startzustand => body.onload
    // alle felder auf beige, feld 1 auf rot

    let elemente = document.getElementsByClassName('felder');

    for(let i = 0; i < 9; i++){

        elemente[i].style.backgroundColor = 'beige';

    }

    elemente[0].style.backgroundColor = 'red';
    localStorage.clear();


}

function start(){


    let elemente = document.getElementsByClassName('felder');

    for(let i = 0; i < 9; i++){

        elemente[i].style.backgroundColor = 'beige';

    }


    if (localStorage.getItem("feld") == null) {
        elemente[0].style.backgroundColor = 'red';
    }
    else{
        let dunno = parseInt(localStorage.getItem("feld"));

        elemente[dunno].style.backgroundColor = 'red';

    }

}
function play(){
    
    

    let elemente = document.getElementsByClassName('felder');    // alle felder prüfen, rotes feld speichern

    for(let i = 0; i < 9; i++){

        if(elemente[i].style.backgroundColor == 'red'){
            feld = i + 1;
        }


    }

    if(frage(feld) == true){         // frage(spielstand) aufrufen, bei richtiger antwort wird das nächste feld rot
        if(feld == 9){
            alert("NICE, durchgespielt!");
            reset();
        }
        else{
            alert("Right Answer!");
            elemente[feld-1].style.backgroundColor = 'beige';
            elemente[feld].style.backgroundColor = 'red';
            localStorage.removeItem("feld");
            localStorage.setItem("feld", feld);
            

        }
    }
    else{
        alert("Wrong Answer.");
    }


}


